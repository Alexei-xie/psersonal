package com.ey.tax.cloud.tpd.groovyScript

import com.ey.cn.tax.framework.execution.IExecutionContext
import com.ey.cn.tax.lite.execution.dataset.IDatasetGroovyRunnable
import org.apache.commons.lang3.StringUtils
import org.apache.groovy.util.Maps

class MPSExportScript implements IDatasetGroovyRunnable {

    @Override
    Object run(Object args, Map<String, Object> dependentDatasets, IExecutionContext executionContext) {
        Map<String, Object> argsMap = (Map<String, Object>) args;
        // 获取需要清洗的数据records
        Object dataScope = argsMap.get("records");
        List<LinkedHashMap<String, Object>> data = (List<LinkedHashMap<String, Object>>) dataScope;
        Map<Integer,String> roleItemMap = Maps.of(0, "STAFF", 1, "SIC", 2, "EIC", 3, "PIC")
        // 遍历数据清洗
        for (LinkedHashMap<String, Object> map : data) {
            map.forEach { String k, Object v ->
                {
                    String fieldName = (String) k ;
                    if (fieldName == "role"){
                        println("v===========>" + v + " (type: " + v.getClass().getName() + ")") //type: java.lang.Short)
                        String itemValue = roleItemMap.get(Integer.valueOf(v as String))
                        if (StringUtils.isNoneBlank(itemValue)) {
                            map.put(fieldName, itemValue)
                        }
                    }else if (fieldName == "region"){
                        map.put(fieldName,"未知")
                    }

                }
            }
        }
        return data;
    }
}
